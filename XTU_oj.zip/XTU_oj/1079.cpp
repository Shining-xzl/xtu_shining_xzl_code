#include <stdio.h>
using namespace std;

int main()
{
	double s=17.0/11.0;
	printf("%g\n",s);
	return 0;
}
