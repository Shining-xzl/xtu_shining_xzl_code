/*#include <cstdio>
using namespace std;

int main()
{
	freopen("in.txt","r",stdin);
	int time;
	scanf("%d",&time);
	while(time--)
	{
		
	}
	return 0;
} 
#include <cstdio>
using namespace std;

int main()
{
	freopen("in.txt","r",stdin);
	int n;
	while(scanf("%d",&n)==1)
	{
		
	}
	return 0;
}
#include <cstdio>
using namespace std;

int main()
{
	freopen("in.txt","w",stdout);
	int con=0;
	printf("1225\n");
	for(int j=1;j<=50;j++)
	for(int i=1;i<j;i++)
	{
		printf("%d %d\n",i,j);
		con++;
	}
	return 0;
}

#include <cstdio>
using namespace std;

void read(int &a)
{
	char c=getchar();
	while(c>'9'||c<'0') c=getchar();
	a=0;
	while(c<='9'&&c>='0')
	{
		a=(a<<3)+(a<<1)+(c^48);
		c=getchar();
	}
	return;
}

int main()
{
	freopen("in.txt","r",stdin);
	int time;
	read(time);
	while(time--)
	{
		
	}
	return 0;
} 
*/
#include<stdio.h>

int main()
{
	int K;
	int n, m;
	double p;
	scanf("%d", &K);
	for (int I = 0; I < K; I++)
	{
		scanf("%d %d", &n, &m);
		p = ((double)m * ((double)m - 1)) / ((double)n * ((double)n - 1));
		p = 1 - p;
		if (p == 1)
		{
			printf("1\n");
		}
		else if (p == 0)
		{
			printf("0\n");
		}
		else
		{
			double M = (double)m * ((double)m - 1);
			double N = (double)n * ((double)n - 1);
x:
			for (int i = 2; i <= M; i++)
			{
				if ((int)M % i == 0 && (int)N % i == 0)
				{
					M /= i;
					N /= i;
					goto x;
				}
			}
			printf("%.0f/%.0f\n", N-M, N);
		}
	}
}
