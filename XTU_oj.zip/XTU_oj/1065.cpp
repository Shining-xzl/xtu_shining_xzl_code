#include <stdio.h>
using namespace std;

int main()
{
	float s;
	scanf("%f",&s);
	printf("%.3f",s);
	return 0;
}
