#include <stdio.h>
#include <math.h>
using namespace std;

int main()
{
	double a;
	a=sqrt(3.2*3.2+4.7*4.7);
	printf("%g\n",a);
	return 0;
}
