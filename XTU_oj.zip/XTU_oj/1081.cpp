#include <stdio.h>
#include <math.h>
using namespace std;

int main()
{
	double a=.5;
	printf("%g\n",a);
	return 0;
}
