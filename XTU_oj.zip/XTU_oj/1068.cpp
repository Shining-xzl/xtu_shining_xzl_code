#include <stdio.h>
#include <math.h>
using namespace std;

int main()
{
	int a;
	scanf("%d",&a);
	if(a>=90&&a<=100) printf("A");
	else printf("B");
	return 0;
}
