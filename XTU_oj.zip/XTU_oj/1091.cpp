#include <cstdio>
using namespace std;

int main()
{
	printf("Hello World\n");
	return 0;
 } 
