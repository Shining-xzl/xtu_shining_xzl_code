#include <stdio.h>
using namespace std;

int main()
{
	double s;
	scanf("%lf",&s);
	printf("%.8lf",s);
	return 0;
}
