#include <stdio.h>
using namespace std;

int main()
{
	int a;
	char s[20];
	scanf("%d%s",&a,&s);
	printf("%d,%s",a,s);
	return 0;
}
