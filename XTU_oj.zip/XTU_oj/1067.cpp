#include <stdio.h>
using namespace std;

int main()
{
	char s;
	scanf("%c",&s);
	printf("The ASCII of '%c' is %d.",s,s);
	return 0;
}
